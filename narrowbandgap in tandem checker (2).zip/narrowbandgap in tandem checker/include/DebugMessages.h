 //#define printInnerConvergence
 //#define printOuterConvergence
 //#define plot_n_p_V